# Ajuster la carte et la stratégie du caddie

## Résultat attendu
- Rapprocher nettement la vue satellite autour du trou pour rendre le tracé et les obstacles lisibles.
- Donner un conseil équilibré de 2 à 3 phrases : décision, cible, puis raison utile.
- Adopter une stratégie de départ juste sur les par 4 et par 5 : privilégier le club qui maximise la progression tout en gardant une zone de retombée raisonnable.
- Ne pas écarter automatiquement le Driver à cause d’un bunker : évaluer si le bunker est réellement dans la dispersion ou franchissable. Recommander un bois ou un lay-up seulement si le danger réduit vraiment la marge du coup.
- Éviter les placements inutilement prudents qui laissent volontairement un très long deuxième coup, tout en conservant le droit de recommander autre chose que le Driver lorsque le tracé le justifie.

## Modifications
- Ajuster le cadrage automatique de la carte avec une marge plus faible et un niveau de zoom minimum adapté à un seul trou.
- Remonter la limite des réponses générales à environ 55–70 mots, sans revenir aux longues explications.
- Enrichir les consignes données à l’IA avec la distance du Driver du joueur et sa zone de retombée par rapport aux obstacles.
- Modifier le conseil automatique du trou pour demander explicitement un club, une cible et la justification du choix.
- Mettre à jour les suggestions du chat de départ pour demander le coup juste et expliquer si un bunker est réellement en jeu.

## Vérification
- Contrôler l’écran du trou sur téléphone avec un parcours cartographié.
- Vérifier qu’un par 4 long et dégagé ne déclenche pas un lay-up par simple présence d’un bunker, et qu’un danger réellement en jeu peut encore justifier un autre choix.
- Vérifier que la lecture orale reste naturelle et ne coupe pas la justification utile.
